<?php

echo 'I\'m alive!';